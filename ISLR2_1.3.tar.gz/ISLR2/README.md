# ISLR2
Introduction to Statistical Learning, Second Edition.
This package contains datasets used in the book "Introduction to Statistical Learning, with Applications in R (second edition)" by Gareth James, Daniela Witten, Trevor Hastie and Rob Tibshirani.
